# Best Practices
This document discusses best practices for running DataStax Enterprise (DSE) on Oracle Cloud Infrastructure (OCI).  The Terraform module aims to configure DSE according to our best practices.  We strongly recommend using that as many of the steps described here are automated.

## Compute

asd

## Storage

asd

## Network

asd

## Security

asd
